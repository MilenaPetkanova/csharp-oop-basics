﻿public interface IBird
{
    double WingSize { get; }
}
