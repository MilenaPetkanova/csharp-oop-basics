﻿public interface IFeline
{
    string Breed { get; }
}