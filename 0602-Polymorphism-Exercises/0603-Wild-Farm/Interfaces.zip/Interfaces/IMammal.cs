﻿public interface IMammal
{
    string LivingRegion { get; }
}
