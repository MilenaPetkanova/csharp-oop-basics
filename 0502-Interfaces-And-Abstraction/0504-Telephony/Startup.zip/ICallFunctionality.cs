﻿public interface ICallFunctionality
{
    string PrintCalling(string number);
}