﻿public interface IBrowseFunctionality
{
    string PrintBrowsing(string url);
}