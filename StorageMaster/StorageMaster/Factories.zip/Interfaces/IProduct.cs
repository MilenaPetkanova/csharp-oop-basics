﻿namespace StorageMaster.Interfaces
{
    public interface IProduct
    {
        double Price { get; }
        double Weight { get; }
    }
}
